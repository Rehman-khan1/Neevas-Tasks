const apikey = "e5730c917dead66f8da0ce5ebee55a52";

async function fetchWeatherData(city) {
    const apiurl = `https://api.openweathermap.org/data/2.5/weather?units=metric&q=${city}&appid=${apikey}`;
    const response = await fetch(apiurl);
    const data = await response.json();
    
    if (response.ok) {
        displayWeatherData(data);
    } else {
        alert("City not found");
    }
}

function displayWeatherData(data) {
    const city = data.name;
    const country = data.sys.country;
    const temp = data.main.temp;
    const desc = data.weather[0].description;
    const icon = data.weather[0].icon;
    const windDeg = data.wind.deg;

    document.getElementById('current-location').textContent = `${city}, ${country}`;
    document.getElementById('temperature').textContent = `${temp}°C`;
    document.getElementById('description').textContent = desc.charAt(0).toUpperCase() + desc.slice(1);
    document.getElementById('weather-icon').src = `http://openweathermap.org/img/wn/${icon}.png`;
    document.getElementById('wind-direction').textContent = `Wind: ${convertWindDirection(windDeg)}`;
}

// Function to convert wind direction from degrees to compass direction
function convertWindDirection(deg) {
    if (deg > 337.5) return 'N';
    if (deg > 292.5) return 'NW';
    if (deg > 247.5) return 'W';
    if (deg > 202.5) return 'SW';
    if (deg > 157.5) return 'S';
    if (deg > 122.5) return 'SE';
    if (deg > 67.5) return 'E';
    if (deg > 22.5) return 'NE';
    return 'N';
}

document.getElementById('search-btn').addEventListener('click', () => {
    const city = document.getElementById('city-input').value;
    if (city) {
        fetchWeatherData(city);
    } else {
        alert("Please enter a city name");
    }
});
